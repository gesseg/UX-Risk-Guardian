from typing import Tuple


def map_to_eu_ai_act(query: str) -> Tuple[str, str]:
    q = query.lower()
    # Very simplified heuristic mapping; short tag with base explanation
    if any(x in q for x in ["biometric", "surveillance", "social scoring"]):
        return ("Prohibited / High-Risk", "Biometric identification/surveillance features can fall under high-risk or prohibited categories under the EU AI Act.")
    if any(x in q for x in ["recruit", "hiring", "credit", "loan", "education", "health"]):
        return ("High-Risk", "Impacts access to essential services or fundamental rights; stricter obligations apply (risk mgmt, data quality, human oversight).")
    if any(x in q for x in ["chatbot", "content generation", "assistive", "ux writing", "summarize", "persona"]):
        return ("Limited-Risk", "Likely transparency obligations (disclose AI use), log events, provide oversight mechanisms.")
    return ("Minimal-Risk", "General-purpose UX support with low rights impact; follow good practices and basic transparency.")


def map_to_other_frameworks(query: str) -> str:
    return (
      "GDPR: assess lawful basis, purpose limitation, data minimization. "
      "NIST AI RMF: Govern → Map → Measure → Manage; document risks and controls. "
      "OECD AI: Inclusive growth, human-centered values, transparency, robustness, accountability."
    )
