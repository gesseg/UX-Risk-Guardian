from typing import List, Dict, Any
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from reportlab.lib.utils import simpleSplit
import os


def export_result_to_pdf(query: str, act_tag: str, act_note: str, blocks: List[Dict[str, Any]], ref_dict: Dict[str, Any]):
    path = f"aura_ux_{os.getpid()}.pdf"
    c = canvas.Canvas(path, pagesize=A4)
    width, height = A4

    def write_wrapped(text, x, y, max_width):
        lines = simpleSplit(text, 'Helvetica', 10, max_width)
        for line in lines:
            c.drawString(x, y, line)
            y -= 12
        return y

    margin = 2*cm
    x = margin
    y = height - margin

    c.setFont("Helvetica-Bold", 12)
    c.drawString(x, y, "Aura UX — UX-Risk-Guardian")
    y -= 16
    c.setFont("Helvetica", 10)
    y = write_wrapped(f"Query: {query}", x, y, width - 2*margin)
    y = write_wrapped(f"EU AI Act: {act_tag} — {act_note}", x, y, width - 2*margin)
    y -= 8

    for block in blocks:
        r = block["risk"]
        c.setFont("Helvetica-Bold", 11)
        y = write_wrapped(f"Risk: {r['title']} (Priority: {r['severity']}; Phase: {r['phase']})", x, y, width - 2*margin)
        c.setFont("Helvetica", 10)
        y = write_wrapped(f"Justification: {r.get('justification','')}", x, y, width - 2*margin)
        y = write_wrapped("Mitigations:", x, y, width - 2*margin)
        for m in r.get("mitigations", [])[:5]:
            y = write_wrapped(f" - {m}", x+12, y, width - 2*margin - 12)
        y = write_wrapped("Evidence:", x, y, width - 2*margin)
        for e in r.get("evidence", [])[:5]:
            y = write_wrapped(f" - {e}", x+12, y, width - 2*margin - 12)
        # references
        ref_ids = r.get("references", [])[:5]
        if ref_ids:
            y = write_wrapped("References:", x, y, width - 2*margin)
            idx = 1
            for rid in ref_ids:
                ref = ref_dict.get(rid)
                if not ref:
                    continue
                line = f"[{idx}] {ref.get('authors','')} ({ref.get('year','')}). {ref.get('title','')} — {ref.get('venue','')} — DOI: {ref.get('doi','')}"
                y = write_wrapped(line, x+12, y, width - 2*margin - 12)
                idx += 1
        y -= 8
        if y < 3*cm:
            c.showPage()
            y = height - margin

    c.save()
    return path
