from typing import List, Dict, Any
import yaml
import re


def load_kb(risks_path: str, refs_path: str):
    with open(risks_path, "r", encoding="utf-8") as f:
        risks = yaml.safe_load(f)
    with open(refs_path, "r", encoding="utf-8") as f:
        refs = yaml.safe_load(f)
    return risks, refs


def _match_score(q: str, text: str) -> int:
    q = q.lower()
    text = text.lower()
    score = 0
    for token in re.findall(r"[a-zA-Z0-9_\-]+", q):
        if token in text:
            score += 1
    return score


def retrieve_by_query(query: str, risks: List[Dict, Any], ref_dict: Dict[str, Any], max_items: int = 5):
    # If query includes phase:xxx, filter by phase
    phase_map = {
        "phase:understand": "Understand",
        "phase:specify": "Specify",
        "phase:create": "Create",
        "phase:evaluate": "Evaluate",
    }
    for key, phase in phase_map.items():
        if key in query.lower():
            filtered = [r for r in risks if r.get("phase") == phase]
            return filtered[:max_items]

    scored = []
    for r in risks:
        blob = " ".join([
            r.get("title", ""),
            r.get("justification", ""),
            " ".join(r.get("evidence", [])),
            " ".join(r.get("mitigations", [])),
        ])
        scored.append((_match_score(query, blob), r))
    scored.sort(key=lambda x: x[0], reverse=True)
    out = [r for s, r in scored if s > 0][:max_items]
    # if nothing matched, return top general risks
    if not out:
        out = risks[:max_items]
    return out


def phase_presets(phase_query: str, risks: List[Dict[str, Any]], ref_dict: Dict[str, Any], max_items: int = 5):
    return retrieve_by_query(phase_query, risks, ref_dict, max_items=max_items)
