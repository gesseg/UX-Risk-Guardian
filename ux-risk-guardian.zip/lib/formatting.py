from typing import Dict, List, Tuple


def build_reference_dict(refs_yaml) -> dict:
    d = {}
    for r in refs_yaml:
        d[r["id"]] = r
    return d


def render_numeric_citations(ref_ids: List[str], ref_dict: Dict[str, dict], start_index: int = 1) -> Tuple[str, List[int]]:
    lines = []
    seen_numbers = []
    i = start_index
    for rid in ref_ids:
        ref = ref_dict.get(rid)
        if not ref:
            continue
        doi_part = f"https://doi.org/{ref['doi']}" if ref.get("doi") else ref.get("url", "")
        authors = ref.get("authors", "").replace("&", "and")
        year = ref.get("year", "?")
        title = ref.get("title", "")
        venue = ref.get("venue", "")
        lines.append(f"[{i}] {authors} ({year}). <i>{title}</i>. {venue}. <br/><a href=\"{doi_part}\" target=\"_blank\">{doi_part}</a>")
        seen_numbers.append(i)
        i += 1
    html = "<br/>".join(lines) if lines else "No references."
    return html, seen_numbers
